const KEY='lexipop_3d_v1';
export function defaultState(){return {level:1,coins:0,activeRelics:[],upgrades:{},totalWords:0,bestWord:'—',bestScore:0,highestLevel:1,runSeed:'LP-START',daily:false,levelWords:0,wordsThisLevel:0,mana:0,moves:5,shuffles:2,spentMoves:0,cleared:false,usedChain:false}}
export function loadState(){try{return {...defaultState(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return defaultState()}}
export function saveState(s){try{localStorage.setItem(KEY,JSON.stringify(s))}catch{}}
export function exportShareText(s,score=0){return `🫧 LexiPop Level ${s.level} | Seed: #${s.runSeed} | Mana: ${score} | Best Word: ${s.bestWord} ✨`}
