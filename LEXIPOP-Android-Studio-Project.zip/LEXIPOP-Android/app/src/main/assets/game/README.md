# LEXIPOP — Playable Web Prototype

LEXIPOP is a no-backend, mobile-first word roguelike prototype with a glossy cartoon presentation, deterministic level seeds, 5×5 board, seven-slot tray, score previews, 16 relic definitions, five boss rules, a coin shop, procedural Web Audio, local save data, and a basic PWA service worker.

## Included app icon

The supplied LEXIPOP artwork is included in `assets/` in multiple PNG sizes. The web manifest, browser icon, Apple touch icon, and service-worker cache are configured to use it. `assets/icon-512.png` is also the PWA install icon.

## Run locally

Because the project uses JavaScript ES modules and a service worker, run it from localhost or HTTPS (not by double-clicking `index.html`).

- Python installed: run `python3 -m http.server 8080` from this folder.
- Open `http://localhost:8080` in a browser.
- On a phone, upload the folder to GitHub Pages or another HTTPS static host, then open the site and use **Add to Home Screen**.

No API keys, account, or backend are required.

## Controls

- Tap a tile or drag across adjacent tiles to build a word.
- Clear, Hint, Shuffle, and Brew Word buttons control the turn.
- Sound and music start after a user interaction (browser autoplay policy).
- Progress is stored in `localStorage` under `lexipop_3d_v1`.

## Current implementation scope

This first runnable build uses a custom Canvas 2D renderer with layered bevels, gradients, glow, and a pseudo-3D toy-box look. It does **not yet use a real Three.js/WebGL scene** because external dependencies could not be fetched in this environment. The current bundled offline lexicon is a compact starter list with morphological rules, not a complete English dictionary. These are explicit next-stage tasks for a true 3D upgrade and expanded dictionary.

The service worker caches the app shell after the first successful online/localhost visit. Browser APIs such as vibration and clipboard depend on device/browser permissions and support.
