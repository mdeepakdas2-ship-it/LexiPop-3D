# LEXIPOP Android project

Android WebView wrapper for the LEXIPOP HTML/JavaScript game. The selected LEXIPOP icon is installed as the Android launcher icon.

## Build
- Android Studio: open this folder, sync Gradle, then Build > Build APK(s).
- Or push this project to GitHub and run the `Build LEXIPOP APK` workflow under Actions.

See `BUILD-APK-HINDI.txt` for exact steps in Hindi/English.
